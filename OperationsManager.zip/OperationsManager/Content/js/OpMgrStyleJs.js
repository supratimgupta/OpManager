﻿$(document).ready(function () {
    $(".disabledDiv :input").attr("disabled", true);
    $(".disabledPlace :input").attr("disabled", "disabled");
});