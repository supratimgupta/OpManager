﻿using OpMgr.Common.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OperationsManager.Areas.Login.Models
{
    public class PasswordVM:PasswordDTO
    {
    }
}