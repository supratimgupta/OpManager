﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OperationsManager.Areas.DataImport.Models
{
    public class DataImportViewModel
    {
        public string Message { get; set; }

        public bool Status { get; set; }
    }
}